import type { Timestamp } from 'firebase/firestore';

export type NavSection =
  | 'overview'
  | 'live_assistant'
  | 'objections'
  | 'closing'
  | 'cold_call'
  | 'product'
  | 'prospects'
  | 'simulation'
  | 'history'
  | 'knowledge'
  | 'learning'
  | 'analytics'
  | 'settings';

export type ThinkingMode = 'auto' | 'fast' | 'deep';
export type AllowedModel = 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';

export type CommunicationStyle =
  | 'Natural'
  | 'Confident'
  | 'Persuasive'
  | 'Professional'
  | 'Friendly'
  | 'Direct'
  | 'Short'
  | 'Detailed';

export type CommunicationChannel =
  | 'WhatsApp'
  | 'Telephone call'
  | 'Email'
  | 'Face-to-face'
  | 'Social media'
  | 'Internal';

export type UserRole = 'owner' | 'administrator' | 'sales_executive';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  role: UserRole;
  preferences?: Record<string, unknown>;
  communicationStyle: CommunicationStyle;
  defaultThinkingMode: ThinkingMode;
  activeWorkspaceId: string;
  accountStatus: 'active' | 'suspended';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface WorkspaceRecord {
  workspaceId: string;
  workspaceName: string;
  companyName: string;
  ownerUid: string;
  visibility: 'private' | 'organization';
  configuration: Record<string, unknown>;
  status: 'active' | 'archived';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ConversationRecord {
  conversationId: string;
  userId: string;
  workspaceId: string;
  prospectId?: string;
  title: string;
  channel: CommunicationChannel;
  mode: ThinkingMode;
  module: 'live_assistant' | 'objection' | 'closing' | 'cold_call' | 'prospect_analysis';
  status: 'active' | 'follow_up' | 'converted' | 'closed_lost';
  outcome?: string;
  analysed: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ConversationMessage {
  messageId: string;
  userId: string;
  role: 'user' | 'assistant' | 'prospect';
  content: string;
  mode: ThinkingMode;
  sourceReferences: string[];
  feedbackStatus: string;
  tokenUsage: number;
  responseLatency: number;
  timestamp?: Timestamp;
}

export interface ProspectRecord {
  prospectId: string;
  userId: string;
  workspaceId: string;
  displayName: string;
  contactDetails?: string;
  tradingExperience: string;
  previousPropFirm?: string;
  preferredAccountSize: string;
  preferredChallenge: string;
  primaryConcern: string;
  objections: string[];
  buyingSignals: string[];
  verifiedNotes: string;
  aiObservations: string;
  followUpDate?: string;
  status: 'new' | 'contacted' | 'qualified' | 'follow_up' | 'converted' | 'declined';
  outcome?: string;
  lastInteraction?: Timestamp;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface KnowledgeSourceRecord {
  sourceId: string;
  workspaceId: string;
  title: string;
  sourceType: 'pdf' | 'docx' | 'txt' | 'csv' | 'url' | 'manual';
  originalFileName?: string;
  storagePath?: string;
  sourceUrl?: string;
  category: string;
  documentVersion: number;
  uploadedBy: string;
  uploadedAt?: Timestamp;
  effectiveDate: string;
  approvalStatus: 'pending' | 'approved' | 'superseded' | 'rejected';
  approvedBy?: string;
  approvedAt?: string;
  contentHash: string;
}

export interface KnowledgeChunkRecord {
  chunkId: string;
  sourceId: string;
  workspaceId: string;
  uploadedBy: string;
  content: string;
  category: string;
  keywords: string[];
  pageNumber: number;
  sectionTitle: string;
  documentVersion: number;
  approvalStatus: 'pending' | 'approved' | 'superseded' | 'rejected';
  createdAt?: Timestamp;
}

export interface UserMemoryRecord {
  memoryId: string;
  userId: string;
  workspaceId: string;
  memoryType:
    | 'communication_style'
    | 'common_objection'
    | 'winning_approach'
    | 'requested_script'
    | 'training_weakness'
    | 'prospect_context'
    | 'preference';
  memoryContent: string;
  confidence: 'high' | 'medium' | 'low';
  sourceConversationId?: string;
  createdAt?: Timestamp;
  lastUsedAt?: Timestamp;
  status: 'active' | 'archived';
}

export type FeedbackType =
  | 'Helpful'
  | 'Not helpful'
  | 'Too long'
  | 'Too robotic'
  | 'Too aggressive'
  | 'Factually incorrect'
  | 'Good closing approach'
  | 'Better alternative';

export interface FeedbackRecord {
  feedbackId: string;
  userId: string;
  conversationId: string;
  messageId: string;
  rating: 'positive' | 'negative';
  feedbackType: FeedbackType;
  comment: string;
  createdAt?: Timestamp;
}

export interface SalesOutcomeRecord {
  outcomeId: string;
  userId: string;
  prospectId?: string;
  conversationId?: string;
  outcomeType: 'replied' | 'meeting_secured' | 'purchased' | 'declined' | 'follow_up_scheduled';
  product: string;
  salesValue: number;
  currency: string;
  strategyUsed: string;
  blockingObjection?: string;
  outcomeNotes: string;
  recordedAt?: Timestamp;
}

export interface SimulationTranscriptTurn {
  speaker: 'executive' | 'prospect';
  text: string;
  timestampIso: string;
}

export interface SimulationCategoryScores {
  opening: number;
  discovery: number;
  listening: number;
  engagement: number;
  productKnowledge: number;
  trustBuilding: number;
  objectionHandling: number;
  persuasion: number;
  closing: number;
}

export interface SimulationRecord {
  simulationId: string;
  userId: string;
  prospectType: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  transcript: SimulationTranscriptTurn[];
  categoryScores: Partial<SimulationCategoryScores>;
  overallScore: number;
  feedback: string;
  improvementTarget: string;
  status: 'in_progress' | 'completed';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface LearningRecord {
  learningId: string;
  workspaceId: string;
  recordType: 'knowledge_gap' | 'strategy_proposal' | 'instruction_version';
  title: string;
  description: string;
  evidenceSummary?: string;
  proposedChange?: string;
  instructionVersion: number;
  status: 'pending_review' | 'approved' | 'rejected' | 'rolled_back';
  createdBy: string;
  reviewedBy?: string;
  reason?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ObjectionAnalysisResult {
  surfaceObjection: string;
  underlyingConcern: string;
  prospectMotivation: string;
  recommendedResponse: string;
  supportingEvidence: string[];
  followUpQuestion: string;
  suggestedNextStep: string;
  alternativeResponses: Array<{ style: string; response: string }>;
  missingKnowledgeGap: string;
}

export interface ClosingAnalysisResult {
  readinessScore: number;
  readinessLabel: string;
  buyingSignals: string[];
  remainingConcerns: string[];
  purchaseMotivation: string;
  productSuitability: string;
  genuineUrgency: string;
  recommendedCloseType: string;
  closeScript: string;
  rationale: string;
  followUpFallback: string;
}

export interface ColdCallPlaybookResult {
  openingLines: string[];
  naturalIntroduction: string;
  attentionQuestions: string[];
  discoveryQuestions: string[];
  productPositioning: string;
  conversationalTransitions: string[];
  objectionPivots: Array<{ objection: string; pivot: string }>;
  closingQuestions: string[];
  followUpStrategy: string;
}

export interface ProductQaResult {
  answer: string;
  verifiedClaims: string[];
  sourceCitations: string[];
  detectedConflicts: string[];
  missingInfoGaps: string[];
  suggestedKnowledgeGapTitle: string;
}

export interface ProspectAnalysisResult {
  tradingExperience: { assessment: string; confidence: string; evidence: string };
  communicationStyle: { assessment: string; confidence: string };
  mainMotivation: { assessment: string; confidence: string };
  mainObjection: { assessment: string; confidence: string };
  trustLevel: { level: string; confidence: string; rationale: string };
  purchaseInterest: { level: string; confidence: string };
  buyingSignals: string[];
  unansweredQuestions: string[];
  missedOpportunities: string[];
  recommendedNextResponse: string;
  suggestedClosingStrategy: string;
  memoryExtractionSuggestions: string[];
}

export interface SimulationScoreResult {
  categoryScores: SimulationCategoryScores;
  overallScore: number;
  strongestArea: string;
  biggestMissedOpportunity: string;
  betterAlternativeResponse: string;
  measurableImprovementTarget: string;
  detailedFeedback: string;
}

export interface StrategyProposalResult {
  title: string;
  description: string;
  evidenceSummary: string;
  proposedChange: string;
  correlationVsCausationNote: string;
  recommendedKnowledgeGaps: string[];
}

export interface ProspectExtractionResult {
  displayName: string;
  contactDetails: string;
  tradingExperience: string;
  previousPropFirm: string;
  preferredChallenge: string;
  preferredAccountSize: string;
  primaryConcern: string;
  objections: string[];
  buyingSignals: string[];
  suggestedStatus: ProspectRecord['status'];
  suggestedFollowUpDays: number;
  verifiedNotes: string;
  aiObservations: string;
}


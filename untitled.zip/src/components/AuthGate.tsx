import { ShieldCheck, TrendingUp } from 'lucide-react';
import { useSalesOs } from '../context/SalesOsContext';

export function AuthGate() {
  const { signInWithGoogle, authError } = useSalesOs();

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-[#070B14] px-4 py-12">
      <div className="w-full max-w-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] rounded-xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-sky-600/15 border border-sky-500/30 flex items-center justify-center text-sky-500">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-slate-900 dark:text-white">
              Thaurus Guru
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Sales Intelligence Operating System
            </p>
          </div>
        </div>

        <h2 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-white mb-3 text-balance">
          Executive Command Centre for Prop Trading Sales
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
          Sign in with your verified Google workspace account to access live sales intelligence,
          verified product retrieval, objection and closing strategy engines, prospect memory, and
          adaptive coaching simulations.
        </p>

        <div className="border-t border-b border-slate-200 dark:border-slate-800 py-4 mb-6 space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center justify-between">
            <span>Intelligence Engine</span>
            <span className="font-mono text-slate-900 dark:text-slate-200">
              Fast Live &amp; Deep Strategic Modes
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Data Persistence</span>
            <span className="font-mono text-slate-900 dark:text-slate-200">
              Firestore Isolated Executive Vault
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Knowledge Governance</span>
            <span className="font-mono text-slate-900 dark:text-slate-200">
              Verified RAG &amp; Versioned Learning
            </span>
          </div>
        </div>

        {authError && (
          <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-300">
            {authError}
          </div>
        )}

        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="w-full py-3 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <ShieldCheck className="w-4 h-4" />
          Sign in with Google
        </button>
      </div>
    </div>
  );
}

import { HardDriveDownload, RefreshCw, ShieldCheck, Smartphone, Wifi, WifiOff } from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { grantAdminRole, updateUserProfile } from '../../services/firestoreService';
import type { AllowedModel, CommunicationStyle, ThinkingMode } from '../../types';
import { PWAInstallButton } from '../PWAInstallButton';

export function SettingsModule() {
  const {
    profile,
    workspaceId,
    isAdmin,
    isOnline,
    offlineLastSyncedAt,
    refreshOfflineCache,
    prospects,
    knowledgeSources,
    knowledgeChunks,
    theme,
    toggleTheme,
    thinkingMode,
    setThinkingMode,
    selectedModel,
    setSelectedModel,
    communicationStyle,
    setCommunicationStyle,
    notify,
  } = useSalesOs();

  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [saving, setSaving] = useState(false);

  const [adminTargetUid, setAdminTargetUid] = useState('');
  const [adminTargetEmail, setAdminTargetEmail] = useState('');

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !displayName.trim()) return;
    setSaving(true);
    try {
      await updateUserProfile(profile.uid, {
        displayName: displayName.trim(),
        communicationStyle,
        defaultThinkingMode: thinkingMode,
      });
      notify('Executive profile preferences saved.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save settings.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleGrantAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !adminTargetUid.trim() || !adminTargetEmail.trim()) return;
    try {
      await grantAdminRole(adminTargetUid.trim(), adminTargetEmail.trim(), profile.uid);
      setAdminTargetUid('');
      setAdminTargetEmail('');
      notify('Administrator privileges granted in /admins.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to grant admin role.', 'error');
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Workspace &amp; Intelligence Settings
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Configure executive communication preferences, Gemini model selection, thinking defaults,
          and appearance.
        </p>
      </div>

      <form
        onSubmit={handleSaveProfile}
        className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">Executive Display Name</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
            />
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Account Role &amp; Workspace</label>
            <div className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 text-xs font-mono text-slate-700 dark:text-slate-300">
              {profile?.role || 'sales_executive'} · {workspaceId}
            </div>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Default Communication Style</label>
            <select
              value={communicationStyle}
              onChange={(e) => setCommunicationStyle(e.target.value as CommunicationStyle)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
            >
              {(
                [
                  'Natural',
                  'Confident',
                  'Persuasive',
                  'Professional',
                  'Friendly',
                  'Direct',
                  'Short',
                  'Detailed',
                ] as CommunicationStyle[]
              ).map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Default Thinking Mode</label>
            <select
              value={thinkingMode}
              onChange={(e) => setThinkingMode(e.target.value as ThinkingMode)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
            >
              <option value="auto">Auto (Adaptive Triage)</option>
              <option value="fast">Fast (Low-Latency Live Mode)</option>
              <option value="deep">Deep (Strategic Analysis Mode)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Gemini Engine Model</label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value as AllowedModel)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
            >
              <option value="gemini-4-hydrogen">Gemini 4 Hydrogen (Fast &amp; Deep Thinking)</option>
              <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Ultra-Low Latency)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Interface Theme</label>
            <button
              type="button"
              onClick={toggleTheme}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm text-left cursor-pointer"
            >
              Current: {theme === 'dark' ? 'Dark Command Interface' : 'Light Executive Interface'}{' '}
              (Click to switch)
            </button>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save Preferences'}
          </button>
        </div>
      </form>

      {/* Mobile PWA & Offline Field Mode */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Smartphone className="w-4 h-4 text-sky-500" />
              <span>Mobile PWA &amp; Offline Field Mode</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Keep Knowledge Base specs and Prospect profiles cached locally on your device when
              mobile data drops.
            </p>
          </div>
          <PWAInstallButton variant="header" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <div className="text-slate-500 flex items-center gap-1.5">
              {isOnline ? (
                <Wifi className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-amber-500" />
              )}
              <span>Connectivity</span>
            </div>
            <div className="font-medium text-slate-900 dark:text-white mt-1">
              {isOnline ? 'Online · Live Sync Active' : 'Offline · Field Cache Active'}
            </div>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <div className="text-slate-500 flex items-center gap-1.5">
              <HardDriveDownload className="w-3.5 h-3.5 text-sky-500" />
              <span>Cached Records</span>
            </div>
            <div className="font-mono text-slate-900 dark:text-white mt-1">
              {knowledgeSources.length} sources · {knowledgeChunks.length} chunks ·{' '}
              {prospects.length} prospects
            </div>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <div className="text-slate-500">Last Local Sync</div>
            <div className="font-mono text-slate-900 dark:text-white mt-1">
              {offlineLastSyncedAt
                ? new Date(offlineLastSyncedAt).toLocaleString([], {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : 'Waiting for initial sync'}
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => {
              refreshOfflineCache();
              notify('Offline field cache refreshed for Knowledge Base & Prospects.', 'success');
            }}
            className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Offline Cache</span>
          </button>
        </div>
      </div>

      {isAdmin && (
        <form
          onSubmit={handleGrantAdmin}
          className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3"
        >
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
            <ShieldCheck className="w-4 h-4 text-sky-500" />
            <span>Administrator Access Governance</span>
          </div>
          <p className="text-xs text-slate-500">
            Grant knowledge-approval and strategy-governance rights to another verified team
            member by UID and email.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <input
              type="text"
              value={adminTargetUid}
              onChange={(e) => setAdminTargetUid(e.target.value)}
              placeholder="Target Firebase UID"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono"
            />
            <input
              type="email"
              value={adminTargetEmail}
              onChange={(e) => setAdminTargetEmail(e.target.value)}
              placeholder="Target verified email"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Grant Administrator Role
          </button>
        </form>
      )}
    </div>
  );
}

import {
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Calendar,
  CheckCircle2,
  Compass,
  Database,
  MessageCircle,
  MessageSquare,
  PhoneCall,
  ShieldAlert,
  Users,
  WifiOff,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { updateProspectFollowUp } from '../../services/firestoreService';
import type { NavSection, ProspectRecord } from '../../types';
import { buildWhatsAppUrl } from '../../utils/whatsapp';

function formatCurrency(val: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(val);
}

function getLocalYmd(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

type FollowUpUrgency = 'overdue' | 'due_today' | 'upcoming' | 'unscheduled';

interface QueuedFollowUp {
  prospect: ProspectRecord;
  urgency: FollowUpUrgency;
  rank: number;
}

export function OverviewModule() {
  const {
    profile,
    isOnline,
    setActiveNav,
    openProspectInLiveAssistant,
    conversations,
    prospects,
    outcomes,
    knowledgeSources,
    knowledgeChunks,
    feedback,
    memories,
    learningRecords,
    simulations,
    currentInstructionVersion,
    notify,
  } = useSalesOs();

  const [updatingFollowUpId, setUpdatingFollowUpId] = useState<string | null>(null);

  const metrics = useMemo(() => {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const todayMs = startOfToday.getTime();

    const todaysConversations = conversations.filter((c) => {
      const ms = c.createdAt?.toMillis?.() ?? 0;
      return ms >= todayMs;
    }).length;

    const todaysOutcomes = outcomes.filter((o) => {
      const ms = o.recordedAt?.toMillis?.() ?? 0;
      return ms >= todayMs;
    }).length;

    const analysedCount = conversations.filter((c) => c.analysed).length;
    const conversions = outcomes.filter((o) => o.outcomeType === 'purchased');
    const totalSalesValue = conversions.reduce((sum, o) => sum + (o.salesValue || 0), 0);
    const followUps = prospects.filter(
      (p) =>
        p.status !== 'converted' &&
        p.status !== 'declined' &&
        (p.status === 'follow_up' || Boolean(p.followUpDate?.trim())),
    ).length;

    // Aggregate common objections from real prospects & declined outcomes
    const objectionMap = new Map<string, number>();
    for (const p of prospects) {
      for (const obj of p.objections ?? []) {
        const clean = obj.trim();
        if (clean) objectionMap.set(clean, (objectionMap.get(clean) ?? 0) + 1);
      }
    }
    for (const o of outcomes) {
      if (o.blockingObjection?.trim()) {
        const clean = o.blockingObjection.trim();
        objectionMap.set(clean, (objectionMap.get(clean) ?? 0) + 1);
      }
    }
    const topObjections = Array.from(objectionMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    // Build 7-day activity buckets from real records
    const trendDays: Array<{ label: string; interactions: number; conversions: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const next = new Date(d);
      next.setDate(d.getDate() + 1);
      const s = d.getTime();
      const e = next.getTime();

      const interactions = conversations.filter((c) => {
        const ms = c.createdAt?.toMillis?.() ?? 0;
        return ms >= s && ms < e;
      }).length;

      const convs = outcomes.filter((o) => {
        const ms = o.recordedAt?.toMillis?.() ?? 0;
        return ms >= s && ms < e && o.outcomeType === 'purchased';
      }).length;

      trendDays.push({
        label: d.toLocaleDateString('en-US', { weekday: 'short' }),
        interactions,
        conversions: convs,
      });
    }

    const approvedSources = knowledgeSources.filter((s) => s.approvalStatus === 'approved').length;
    const pendingSources = knowledgeSources.filter((s) => s.approvalStatus === 'pending').length;
    const approvedChunks = knowledgeChunks.filter((c) => c.approvalStatus === 'approved').length;
    const openGaps = learningRecords.filter(
      (l) => l.recordType === 'knowledge_gap' && l.status === 'pending_review',
    ).length;

    return {
      todaysActivity: todaysConversations + todaysOutcomes,
      totalConversations: conversations.length,
      analysedCount,
      conversionsCount: conversions.length,
      totalSalesValue,
      followUps,
      topObjections,
      trendDays,
      approvedSources,
      pendingSources,
      approvedChunks,
      openGaps,
    };
  }, [conversations, prospects, outcomes, knowledgeSources, knowledgeChunks, learningRecords]);

  const followUpQueue = useMemo(() => {
    const todayYmd = getLocalYmd(0);
    const queued: QueuedFollowUp[] = [];

    for (const p of prospects) {
      if (p.status === 'converted' || p.status === 'declined') continue;
      const dateStr = p.followUpDate?.trim() || '';
      if (!dateStr && p.status !== 'follow_up') continue;

      let urgency: FollowUpUrgency = 'upcoming';
      let rank = 3;
      if (!dateStr) {
        urgency = 'unscheduled';
        rank = 2;
      } else if (dateStr < todayYmd) {
        urgency = 'overdue';
        rank = 0;
      } else if (dateStr === todayYmd) {
        urgency = 'due_today';
        rank = 1;
      }

      queued.push({ prospect: p, urgency, rank });
    }

    queued.sort((a, b) => {
      if (a.rank !== b.rank) return a.rank - b.rank;
      const da = a.prospect.followUpDate || '9999-12-31';
      const dbDate = b.prospect.followUpDate || '9999-12-31';
      if (da !== dbDate) return da.localeCompare(dbDate);
      return a.prospect.displayName.localeCompare(b.prospect.displayName);
    });

    return {
      items: queued,
      overdueCount: queued.filter((q) => q.urgency === 'overdue').length,
      dueTodayCount: queued.filter((q) => q.urgency === 'due_today').length,
    };
  }, [prospects]);

  const handleMarkDone = async (prospect: ProspectRecord) => {
    setUpdatingFollowUpId(prospect.prospectId);
    try {
      await updateProspectFollowUp(prospect.prospectId, {
        status: 'contacted',
        followUpDate: '',
      });
      notify(`Marked ${prospect.displayName} follow-up complete.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to update follow-up.', 'error');
    } finally {
      setUpdatingFollowUpId(null);
    }
  };

  const handleSnoozeTwoDays = async (prospect: ProspectRecord) => {
    setUpdatingFollowUpId(prospect.prospectId);
    const nextDate = getLocalYmd(2);
    try {
      await updateProspectFollowUp(prospect.prospectId, {
        status: 'follow_up',
        followUpDate: nextDate,
      });
      notify(`Rescheduled ${prospect.displayName} to ${nextDate}.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to reschedule follow-up.', 'error');
    } finally {
      setUpdatingFollowUpId(null);
    }
  };

  const quickActions: Array<{
    title: string;
    subtitle: string;
    nav: NavSection;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      title: 'Start Live Sales',
      subtitle: 'Real-time WhatsApp, call & email co-pilot',
      nav: 'live_assistant',
      icon: MessageSquare,
    },
    {
      title: 'Handle an Objection',
      subtitle: 'Deconstruct pushback & reply with verified proof',
      nav: 'objections',
      icon: ShieldAlert,
    },
    {
      title: 'Analyse a Prospect',
      subtitle: 'Extract buying signals, trust & next close',
      nav: 'prospects',
      icon: Users,
    },
    {
      title: 'Practise a Cold Call',
      subtitle: 'Generate two-way opening & discovery lines',
      nav: 'cold_call',
      icon: PhoneCall,
    },
    {
      title: 'Explain a Product',
      subtitle: 'Search verified Thaurus Guru challenge rules',
      nav: 'product',
      icon: Compass,
    },
    {
      title: 'Review My Performance',
      subtitle: 'Inspect conversion funnel & simulation scores',
      nav: 'analytics',
      icon: BarChart3,
    },
  ];

  const maxTrend = Math.max(1, ...metrics.trendDays.map((d) => d.interactions));

  return (
    <div className="space-y-6">
      {/* Executive Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <p className="text-xs font-medium text-sky-600 dark:text-sky-400 mb-1">
            Thaurus Guru Sales Command
          </p>
          <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight text-slate-900 dark:text-white text-balance">
            Welcome back, {profile?.displayName || 'Executive'}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Live Firestore telemetry, verified product intelligence, and adaptive coaching active at
            instruction version <span className="font-mono">v{currentInstructionVersion}</span>.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setActiveNav('live_assistant')}
          className="px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-medium transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer self-start md:self-auto"
        >
          <span>Open Live Assistant</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Primary KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500 dark:text-slate-400">Today&apos;s Activity</div>
          <div className="text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {metrics.todaysActivity}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Sessions &amp; outcomes logged
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500 dark:text-slate-400">Total Conversations</div>
          <div className="text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {metrics.totalConversations}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            <span className="font-mono">{metrics.analysedCount}</span> analysed
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500 dark:text-slate-400">Conversions Recorded</div>
          <div className="text-2xl font-semibold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
            {metrics.conversionsCount}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono tabular-nums">
            {formatCurrency(metrics.totalSalesValue)} value
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500 dark:text-slate-400">Follow-Up Pipeline</div>
          <div className="text-2xl font-semibold font-mono tabular-nums text-amber-600 dark:text-amber-400 mt-1">
            {metrics.followUps}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Active prospects queued
          </div>
        </div>

        <div className="col-span-2 lg:col-span-1 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500 dark:text-slate-400">Knowledge Base</div>
          <div className="text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {metrics.approvedSources}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            <span className="font-mono">{metrics.approvedChunks}</span> chunks ·{' '}
            <span className="font-mono">{metrics.pendingSources}</span> pending
          </div>
        </div>
      </div>

      {/* Today's Follow-Ups Priority Queue */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-500" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                Today&apos;s Follow-Ups Queue
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Prioritized by overdue &amp; due-today followUpDate ·{' '}
              <span className="font-mono text-red-500 dark:text-red-400">
                {followUpQueue.overdueCount} overdue
              </span>{' '}
              ·{' '}
              <span className="font-mono text-amber-600 dark:text-amber-400">
                {followUpQueue.dueTodayCount} due today
              </span>
              {!isOnline && (
                <>
                  {' '}
                  ·{' '}
                  <span className="inline-flex items-center gap-1 text-amber-500">
                    <WifiOff className="w-3 h-3" />
                    Offline cache
                  </span>
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveNav('prospects')}
            className="text-xs text-sky-600 dark:text-sky-400 hover:underline self-start sm:self-auto cursor-pointer"
          >
            Open Prospect Memory
          </button>
        </div>

        {followUpQueue.items.length === 0 ? (
          <div className="py-6 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-500 dark:text-slate-400">
            No prospects currently scheduled for follow-up. Set a Follow-Up Date on any prospect or
            extract one directly from Live Sales Assistant.
          </div>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {followUpQueue.items.slice(0, 6).map(({ prospect: p, urgency }) => {
              const waHref = buildWhatsAppUrl(
                `Hi ${p.displayName}, checking in on ${p.preferredChallenge || 'your Thaurus Guru trading account'}—happy to answer any questions.`,
                p.contactDetails,
              );
              const urgencyLabel =
                urgency === 'overdue'
                  ? `Overdue · ${p.followUpDate}`
                  : urgency === 'due_today'
                    ? `Due Today · ${p.followUpDate}`
                    : urgency === 'unscheduled'
                      ? 'Needs Date'
                      : `Scheduled · ${p.followUpDate}`;
              const urgencyColor =
                urgency === 'overdue'
                  ? 'text-red-600 dark:text-red-400'
                  : urgency === 'due_today'
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-slate-500 dark:text-slate-400';

              return (
                <div
                  key={p.prospectId}
                  className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium text-slate-900 dark:text-white truncate">
                        {p.displayName}
                      </span>
                      <span className={`text-[11px] font-mono font-medium ${urgencyColor}`}>
                        {urgencyLabel}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                      {p.preferredChallenge || 'General challenge'} ·{' '}
                      {p.preferredAccountSize || 'Size TBD'} ·{' '}
                      {p.primaryConcern || 'Follow up on next step'}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => openProspectInLiveAssistant(p.prospectId)}
                      className="px-2.5 py-1.5 rounded-lg bg-sky-600/12 text-sky-600 dark:text-sky-400 hover:bg-sky-600/20 text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>Live Reply</span>
                    </button>

                    <a
                      href={waHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-600/12 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600/20 text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <MessageCircle className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      disabled={updatingFollowUpId === p.prospectId}
                      onClick={() => void handleSnoozeTwoDays(p)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                      title="Reschedule follow-up by 2 days"
                    >
                      +2d
                    </button>

                    <button
                      type="button"
                      disabled={updatingFollowUpId === p.prospectId}
                      onClick={() => void handleMarkDone(p)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 hover:border-emerald-500/50 hover:text-emerald-600 dark:hover:text-emerald-400 disabled:opacity-50 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                      title="Mark follow-up complete"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Done</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick-Action Launchpad */}
      <div>
        <h2 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
          Operational Quick Actions
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickActions.map((qa) => {
            const Icon = qa.icon;
            return (
              <button
                key={qa.nav}
                type="button"
                onClick={() => setActiveNav(qa.nav)}
                className="group p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] hover:border-sky-500/50 transition-colors text-left flex items-start justify-between gap-3 cursor-pointer"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white group-hover:text-sky-500 transition-colors">
                    <Icon className="w-4 h-4 text-sky-500 shrink-0" />
                    <span className="truncate">{qa.title}</span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                    {qa.subtitle}
                  </p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-sky-500 shrink-0 mt-0.5" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Middle Split: 7-Day Activity Trend + Common Objections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                7-Day Sales Activity Trend
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Real conversations &amp; purchases recorded in Firestore
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              {conversations.length} total threads
            </span>
          </div>

          {conversations.length === 0 && outcomes.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                No sales activity recorded yet.
              </p>
              <button
                type="button"
                onClick={() => setActiveNav('live_assistant')}
                className="mt-3 px-3.5 py-1.5 rounded-lg bg-sky-600 text-white text-xs font-medium hover:bg-sky-500 cursor-pointer"
              >
                Start First Live Session
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-7 gap-2 items-end h-40 pt-4">
              {metrics.trendDays.map((day) => {
                const heightPct = Math.max(8, Math.round((day.interactions / maxTrend) * 100));
                return (
                  <div key={day.label} className="flex flex-col items-center gap-2 h-full justify-end">
                    <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {day.interactions}
                    </div>
                    <div className="w-full max-w-[36px] bg-slate-100 dark:bg-slate-800/80 rounded-md h-24 flex items-end overflow-hidden">
                      <div
                        className="w-full bg-sky-500/80 rounded-t-md transition-all"
                        style={{ height: `${heightPct}%` }}
                      />
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{day.label}</div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Most Common Objections
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Derived from saved prospect profiles &amp; declined deals
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveNav('objections')}
              className="text-xs text-sky-600 dark:text-sky-400 hover:underline cursor-pointer"
            >
              Open Engine
            </button>
          </div>

          {metrics.topObjections.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                No prospect objections logged yet.
              </p>
              <button
                type="button"
                onClick={() => setActiveNav('prospects')}
                className="mt-3 px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Add Prospect Profile
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {metrics.topObjections.map(([obj, count]) => (
                <div key={obj} className="py-2.5 flex items-center justify-between gap-3">
                  <span className="text-sm text-slate-800 dark:text-slate-200 truncate">{obj}</span>
                  <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                    {count} {count === 1 ? 'record' : 'records'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Split: Knowledge Status + AI Learning Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-sky-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Knowledge Base Governance
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setActiveNav('knowledge')}
              className="text-xs text-sky-600 dark:text-sky-400 hover:underline cursor-pointer"
            >
              Manage Sources
            </button>
          </div>
          {knowledgeSources.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              No product documents or web snapshots have been imported yet. Import official
              Thaurus Guru documentation from <span className="font-mono">thaurusguru.com</span> or
              upload PDF, DOCX, TXT, or CSV policies in Knowledge Base to enable RAG citations.
            </p>
          ) : (
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800/70">
                <span>Approved Official Sources</span>
                <span className="font-mono tabular-nums">{metrics.approvedSources}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800/70">
                <span>Searchable Approved Chunks</span>
                <span className="font-mono tabular-nums">{metrics.approvedChunks}</span>
              </div>
              <div className="flex justify-between py-1">
                <span>Open Knowledge Gaps</span>
                <span className="font-mono tabular-nums">{metrics.openGaps}</span>
              </div>
            </div>
          )}
        </div>

        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-teal-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Adaptive Learning Activity
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setActiveNav('learning')}
              className="text-xs text-sky-600 dark:text-sky-400 hover:underline cursor-pointer"
            >
              Open Learning Centre
            </button>
          </div>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800/70">
              <span>Active Personal Memories (Layer 1)</span>
              <span className="font-mono tabular-nums">
                {memories.filter((m) => m.status === 'active').length}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800/70">
              <span>Executive Feedback Records (Layer 2)</span>
              <span className="font-mono tabular-nums">{feedback.length}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800/70">
              <span>Sales Outcomes Recorded (Layer 3)</span>
              <span className="font-mono tabular-nums">{outcomes.length}</span>
            </div>
            <div className="flex justify-between py-1">
              <span>Completed Simulations</span>
              <span className="font-mono tabular-nums">
                {simulations.filter((s) => s.status === 'completed').length}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

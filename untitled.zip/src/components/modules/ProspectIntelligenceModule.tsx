import {
  Brain,
  Calendar,
  Edit3,
  MessageCircle,
  MessageSquare,
  Plus,
  Search,
  Trash2,
  UserCheck,
  WifiOff,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import { deleteProspect, saveProspect, saveUserMemory } from '../../services/firestoreService';
import type { ProspectAnalysisResult, ProspectRecord } from '../../types';
import { buildWhatsAppUrl } from '../../utils/whatsapp';

export function ProspectIntelligenceModule() {
  const {
    firebaseUser,
    workspaceId,
    isOnline,
    offlineLastSyncedAt,
    prospects,
    draftAnalysisText,
    setDraftAnalysisText,
    openProspectInLiveAssistant,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [tab, setTab] = useState<'analyze' | 'directory'>('analyze');
  const [prospectNameInput, setProspectNameInput] = useState('');
  const [transcriptInput, setTranscriptInput] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ProspectAnalysisResult | null>(null);

  // Directory / Profile Editor state
  const [searchTerm, setSearchTerm] = useState('');
  const [followUpOnly, setFollowUpOnly] = useState(false);
  const [editingProspect, setEditingProspect] = useState<ProspectRecord | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [formDisplayName, setFormDisplayName] = useState('');
  const [formContact, setFormContact] = useState('');
  const [formExperience, setFormExperience] = useState('');
  const [formPrevFirm, setFormPrevFirm] = useState('');
  const [formChallenge, setFormChallenge] = useState('');
  const [formSize, setFormSize] = useState('');
  const [formConcern, setFormConcern] = useState('');
  const [formObjections, setFormObjections] = useState('');
  const [formSignals, setFormSignals] = useState('');
  const [formVerifiedNotes, setFormVerifiedNotes] = useState('');
  const [formAiObs, setFormAiObs] = useState('');
  const [formFollowUp, setFormFollowUp] = useState('');
  const [formStatus, setFormStatus] = useState<ProspectRecord['status']>('qualified');

  useEffect(() => {
    if (draftAnalysisText) {
      setTranscriptInput(draftAnalysisText);
      setTab('analyze');
      setDraftAnalysisText('');
    }
  }, [draftAnalysisText, setDraftAnalysisText]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transcriptInput.trim()) return;
    setAnalyzing(true);
    try {
      const ctx = buildAiContext(transcriptInput);
      const res = await apiPostJson<{ data: ProspectAnalysisResult }>('/api/ai/prospect-analyze', {
        conversationText: transcriptInput,
        prospectName: prospectNameInput || 'Prospect',
        context: ctx,
      });
      setAnalysis(res.data);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Prospect analysis failed.', 'error');
    } finally {
      setAnalyzing(false);
    }
  };

  const openEditorForNew = () => {
    setEditingProspect(null);
    setFormDisplayName(prospectNameInput || '');
    setFormContact('');
    setFormExperience(analysis ? analysis.tradingExperience.assessment : '');
    setFormPrevFirm('');
    setFormChallenge('');
    setFormSize('');
    setFormConcern(analysis ? analysis.mainObjection.assessment : '');
    setFormObjections(analysis ? analysis.mainObjection.assessment : '');
    setFormSignals(analysis ? analysis.buyingSignals.join(', ') : '');
    setFormVerifiedNotes('');
    setFormAiObs(
      analysis
        ? `Style: ${analysis.communicationStyle.assessment} (${analysis.communicationStyle.confidence} confidence). Motivation: ${analysis.mainMotivation.assessment}. Trust: ${analysis.trustLevel.level} (${analysis.trustLevel.confidence}). Next: ${analysis.recommendedNextResponse}`
        : '',
    );
    setFormFollowUp('');
    setFormStatus('qualified');
    setShowForm(true);
    setTab('directory');
  };

  const openEditorForExisting = (p: ProspectRecord) => {
    setEditingProspect(p);
    setFormDisplayName(p.displayName);
    setFormContact(p.contactDetails || '');
    setFormExperience(p.tradingExperience);
    setFormPrevFirm(p.previousPropFirm || '');
    setFormChallenge(p.preferredChallenge);
    setFormSize(p.preferredAccountSize);
    setFormConcern(p.primaryConcern);
    setFormObjections((p.objections ?? []).join(', '));
    setFormSignals((p.buyingSignals ?? []).join(', '));
    setFormVerifiedNotes(p.verifiedNotes);
    setFormAiObs(p.aiObservations);
    setFormFollowUp(p.followUpDate || '');
    setFormStatus(p.status);
    setShowForm(true);
    setTab('directory');
  };

  const handleSaveProspect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !workspaceId || !formDisplayName.trim()) return;
    try {
      await saveProspect({
        prospectId: editingProspect?.prospectId,
        userId: firebaseUser.uid,
        workspaceId,
        displayName: formDisplayName,
        contactDetails: formContact,
        tradingExperience: formExperience,
        previousPropFirm: formPrevFirm,
        preferredChallenge: formChallenge,
        preferredAccountSize: formSize,
        primaryConcern: formConcern,
        objections: formObjections.split(',').map((s) => s.trim()).filter(Boolean),
        buyingSignals: formSignals.split(',').map((s) => s.trim()).filter(Boolean),
        verifiedNotes: formVerifiedNotes,
        aiObservations: formAiObs,
        followUpDate: formFollowUp,
        status: formStatus,
      });
      setShowForm(false);
      setEditingProspect(null);
      notify('Prospect profile saved to Firestore.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save prospect.', 'error');
    }
  };

  const handleSaveSuggestedMemory = async (memText: string) => {
    if (!firebaseUser || !workspaceId) return;
    try {
      await saveUserMemory({
        userId: firebaseUser.uid,
        workspaceId,
        memoryType: 'prospect_context',
        memoryContent: memText,
        confidence: 'medium',
      });
      notify('Saved to Layer 1 Personal Memory.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save memory.', 'error');
    }
  };

  const filteredProspects = prospects.filter((p) => {
    if (followUpOnly && p.status !== 'follow_up' && !p.followUpDate?.trim()) {
      return false;
    }
    const q = searchTerm.toLowerCase();
    return (
      !q ||
      p.displayName.toLowerCase().includes(q) ||
      p.preferredChallenge.toLowerCase().includes(q) ||
      p.primaryConcern.toLowerCase().includes(q) ||
      (p.contactDetails || '').toLowerCase().includes(q) ||
      (p.previousPropFirm || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
            Prospect Intelligence &amp; Memory
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Analyse transcripts with confidence-rated inferences and maintain separated Verified vs
            AI prospect profiles.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 self-start">
          <button
            type="button"
            onClick={() => setTab('analyze')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
              tab === 'analyze'
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Analysis Engine
          </button>
          <button
            type="button"
            onClick={() => setTab('directory')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
              tab === 'directory'
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Prospect Memory ({prospects.length})
          </button>
        </div>
      </div>

      {!isOnline && (
        <div className="p-3 rounded-xl border border-amber-500/35 bg-amber-500/10 text-xs text-amber-800 dark:text-amber-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-amber-500 shrink-0" />
            <span>
              Offline Field Mode active — all {prospects.length} saved Prospect profiles remain
              browsable locally
              {offlineLastSyncedAt
                ? ` (synced ${new Date(offlineLastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`
                : ''}
              . Live AI transcript analysis resumes when online.
            </span>
          </div>
          {tab === 'analyze' && (
            <button
              type="button"
              onClick={() => setTab('directory')}
              className="px-2.5 py-1 rounded bg-amber-600 text-white text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
            >
              Browse Offline Profiles
            </button>
          )}
        </div>
      )}

      {tab === 'analyze' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <form
            onSubmit={handleAnalyze}
            className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4 h-fit"
          >
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Prospect Name / Alias
              </label>
              <input
                type="text"
                value={prospectNameInput}
                onChange={(e) => setProspectNameInput(e.target.value)}
                placeholder="e.g. Chinedu O. (Lagos Trader)"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Complete Conversation Transcript
              </label>
              <textarea
                rows={10}
                value={transcriptInput}
                onChange={(e) => setTranscriptInput(e.target.value)}
                placeholder="Paste WhatsApp chat, call notes, or email thread..."
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={analyzing || !transcriptInput.trim()}
              className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium cursor-pointer"
            >
              {analyzing ? 'Analysing Prospect...' : 'Run Prospect Analysis'}
            </button>
          </form>

          <div className="lg:col-span-7">
            {!analysis ? (
              <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
                <Brain className="w-8 h-8 text-sky-500 mx-auto mb-3" />
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Paste a conversation to generate prospect intelligence
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                  Every psychological and commercial inference carries an explicit confidence level
                  and stays strictly separated from verified prospect facts.
                </p>
              </div>
            ) : (
              <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-5">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    AI Prospect Observations (Confidence-Rated)
                  </h3>
                  <button
                    type="button"
                    onClick={openEditorForNew}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Save to Prospect Profile</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <div className="text-slate-500">
                      Trading Experience ·{' '}
                      <span className="font-mono text-sky-500">
                        {analysis.tradingExperience.confidence} confidence
                      </span>
                    </div>
                    <div className="text-slate-900 dark:text-white font-medium mt-1">
                      {analysis.tradingExperience.assessment}
                    </div>
                    <div className="text-slate-500 mt-1">
                      Evidence: {analysis.tradingExperience.evidence}
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <div className="text-slate-500">
                      Trust Level ·{' '}
                      <span className="font-mono text-sky-500">
                        {analysis.trustLevel.confidence} confidence
                      </span>
                    </div>
                    <div className="text-slate-900 dark:text-white font-medium mt-1">
                      {analysis.trustLevel.level}
                    </div>
                    <div className="text-slate-500 mt-1">{analysis.trustLevel.rationale}</div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <div className="text-slate-500">
                      Main Motivation ·{' '}
                      <span className="font-mono text-sky-500">
                        {analysis.mainMotivation.confidence} confidence
                      </span>
                    </div>
                    <div className="text-slate-900 dark:text-white mt-1">
                      {analysis.mainMotivation.assessment}
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <div className="text-slate-500">
                      Purchase Interest ·{' '}
                      <span className="font-mono text-sky-500">
                        {analysis.purchaseInterest.confidence} confidence
                      </span>
                    </div>
                    <div className="text-slate-900 dark:text-white mt-1">
                      {analysis.purchaseInterest.level} (Style:{' '}
                      {analysis.communicationStyle.assessment})
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-3 border-t border-slate-200 dark:border-slate-800">
                  <div>
                    <div className="font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
                      Buying Signals
                    </div>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                      {analysis.buyingSignals.map((s, i) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="font-semibold text-amber-600 dark:text-amber-400 mb-1">
                      Unanswered Questions
                    </div>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                      {analysis.unansweredQuestions.map((q, i) => (
                        <li key={i}>{q}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="font-semibold text-red-600 dark:text-red-400 mb-1">
                      Missed Opportunities
                    </div>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                      {analysis.missedOpportunities.map((m, i) => (
                        <li key={i}>{m}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Recommended Next Response:{' '}
                    </span>
                    <span className="text-slate-700 dark:text-slate-300">
                      {analysis.recommendedNextResponse}
                    </span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Suggested Closing Strategy:{' '}
                    </span>
                    <span className="text-slate-700 dark:text-slate-300">
                      {analysis.suggestedClosingStrategy}
                    </span>
                  </div>
                </div>

                {analysis.memoryExtractionSuggestions.length > 0 && (
                  <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Save Insights to Layer 1 Personal Memory
                    </div>
                    <div className="space-y-1.5">
                      {analysis.memoryExtractionSuggestions.map((mem, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between gap-2 text-xs p-2 rounded bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800"
                        >
                          <span className="text-slate-700 dark:text-slate-300">{mem}</span>
                          <button
                            type="button"
                            onClick={() => void handleSaveSuggestedMemory(mem)}
                            className="px-2.5 py-1 rounded bg-sky-600 text-white text-xs whitespace-nowrap cursor-pointer"
                          >
                            Save Memory
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Prospect Directory & Memory */
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-full sm:w-72">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search prospects..."
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0D1322] text-xs"
                />
              </div>
              <button
                type="button"
                onClick={() => setFollowUpOnly((v) => !v)}
                className={`px-3 py-2 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  followUpOnly
                    ? 'border-amber-500/60 bg-amber-500/12 text-amber-600 dark:text-amber-400'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0D1322] text-slate-600 dark:text-slate-300'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Follow-Ups Only</span>
              </button>
            </div>
            <button
              type="button"
              onClick={() => {
                setAnalysis(null);
                openEditorForNew();
              }}
              className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium inline-flex items-center gap-1.5 self-start sm:self-auto whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Prospect</span>
            </button>
          </div>

          {showForm && (
            <form
              onSubmit={handleSaveProspect}
              className="p-5 rounded-xl border border-sky-500/40 bg-white dark:bg-[#0D1322] space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  {editingProspect ? `Edit ${editingProspect.displayName}` : 'New Prospect Profile'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-500 mb-1">Display Name / Alias *</label>
                  <input
                    required
                    type="text"
                    value={formDisplayName}
                    onChange={(e) => setFormDisplayName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Optional Contact (If Supplied)</label>
                  <input
                    type="text"
                    value={formContact}
                    onChange={(e) => setFormContact(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Sales Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as ProspectRecord['status'])}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="new">New</option>
                    <option value="contacted">Contacted</option>
                    <option value="qualified">Qualified</option>
                    <option value="follow_up">Follow-Up</option>
                    <option value="converted">Converted</option>
                    <option value="declined">Declined</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-500 mb-1">Trading Experience</label>
                  <input
                    type="text"
                    value={formExperience}
                    onChange={(e) => setFormExperience(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Previous Prop Firm</label>
                  <input
                    type="text"
                    value={formPrevFirm}
                    onChange={(e) => setFormPrevFirm(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Follow-Up Date</label>
                  <input
                    type="date"
                    value={formFollowUp}
                    onChange={(e) => setFormFollowUp(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 mb-1">Preferred Challenge</label>
                  <input
                    type="text"
                    value={formChallenge}
                    onChange={(e) => setFormChallenge(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Account-Size Interest</label>
                  <input
                    type="text"
                    value={formSize}
                    onChange={(e) => setFormSize(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Primary Concern</label>
                  <input
                    type="text"
                    value={formConcern}
                    onChange={(e) => setFormConcern(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-500 mb-1">Objections (comma-separated)</label>
                  <input
                    type="text"
                    value={formObjections}
                    onChange={(e) => setFormObjections(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">
                    Buying Signals (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={formSignals}
                    onChange={(e) => setFormSignals(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-medium text-emerald-600 dark:text-emerald-400 mb-1">
                    Verified Prospect Information (Executive-Confirmed Facts)
                  </label>
                  <textarea
                    rows={3}
                    value={formVerifiedNotes}
                    onChange={(e) => setFormVerifiedNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-sky-600 dark:text-sky-400 mb-1">
                    AI-Generated Observations (Confidence-Rated Inferences)
                  </label>
                  <textarea
                    rows={3}
                    value={formAiObs}
                    onChange={(e) => setFormAiObs(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium cursor-pointer"
                >
                  Save Prospect Record
                </button>
              </div>
            </form>
          )}

          {filteredProspects.length === 0 ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center text-sm text-slate-500">
              No prospect records yet. Analyse a conversation or add a prospect manually.
            </div>
          ) : (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-4 font-medium">Prospect</th>
                    <th className="py-3 px-4 font-medium">Challenge &amp; Size</th>
                    <th className="py-3 px-4 font-medium">Primary Concern</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium">Follow-Up</th>
                    <th className="py-3 px-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredProspects.map((p) => (
                    <tr
                      key={p.prospectId}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 dark:text-white">
                          {p.displayName}
                        </div>
                        <div className="text-slate-500 font-mono text-[11px]">{p.prospectId}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                        {p.preferredChallenge || '—'} · {p.preferredAccountSize || '—'}
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400 max-w-xs truncate">
                        {p.primaryConcern || '—'}
                      </td>
                      <td className="py-3 px-4 capitalize text-slate-800 dark:text-slate-200">
                        {p.status.replace('_', ' ')}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {p.followUpDate || '—'}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => openProspectInLiveAssistant(p.prospectId)}
                            className="p-1.5 text-slate-500 hover:text-sky-500 cursor-pointer"
                            title="Open in Live Sales Assistant"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <a
                            href={buildWhatsAppUrl(
                              `Hi ${p.displayName}, checking in regarding ${p.preferredChallenge || 'your Thaurus Guru trading account'}.`,
                              p.contactDetails,
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 text-slate-500 hover:text-emerald-500"
                            title="Message on WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                          <button
                            type="button"
                            onClick={() => openEditorForExisting(p)}
                            className="p-1.5 text-slate-500 hover:text-sky-500 cursor-pointer"
                            title="Edit prospect"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => void deleteProspect(p.prospectId)}
                            className="p-1.5 text-slate-500 hover:text-red-500 cursor-pointer"
                            title="Delete prospect"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

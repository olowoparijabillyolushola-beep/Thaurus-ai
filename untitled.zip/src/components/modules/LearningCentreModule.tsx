import { Check, Plus, RotateCcw, Sparkles, Trash2, X } from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import {
  createLearningRecord,
  deleteUserMemory,
  reviewLearningRecord,
  saveUserMemory,
} from '../../services/firestoreService';
import type { StrategyProposalResult, UserMemoryRecord } from '../../types';

export function LearningCentreModule() {
  const {
    firebaseUser,
    workspaceId,
    isAdmin,
    memories,
    feedback,
    outcomes,
    learningRecords,
    currentInstructionVersion,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [memType, setMemType] = useState<UserMemoryRecord['memoryType']>('winning_approach');
  const [memContent, setMemContent] = useState('');
  const [memConf, setMemConf] = useState<UserMemoryRecord['confidence']>('high');
  const [synthesizing, setSynthesizing] = useState(false);

  const positiveFb = feedback.filter((f) => f.rating === 'positive');
  const negativeFb = feedback.filter((f) => f.rating === 'negative');

  const weaknessCounts = new Map<string, number>();
  for (const f of negativeFb) {
    weaknessCounts.set(f.feedbackType, (weaknessCounts.get(f.feedbackType) ?? 0) + 1);
  }
  const commonWeaknesses = Array.from(weaknessCounts.entries()).sort((a, b) => b[1] - a[1]);

  const knowledgeGaps = learningRecords.filter((r) => r.recordType === 'knowledge_gap');
  const strategyRecords = learningRecords.filter((r) => r.recordType !== 'knowledge_gap');

  const handleAddMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !workspaceId || !memContent.trim()) return;
    try {
      await saveUserMemory({
        userId: firebaseUser.uid,
        workspaceId,
        memoryType: memType,
        memoryContent: memContent.trim(),
        confidence: memConf,
      });
      setMemContent('');
      notify('Added personal memory (Layer 1).', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save memory.', 'error');
    }
  };

  const handleSynthesizeStrategy = async () => {
    if (!firebaseUser || !workspaceId) return;
    if (feedback.length === 0 && outcomes.length === 0) {
      notify('Record feedback or sales outcomes first so strategy synthesis uses real evidence.', 'error');
      return;
    }
    setSynthesizing(true);
    try {
      const ctx = buildAiContext('Synthesize Layer 5 sales strategy improvements');
      const res = await apiPostJson<{ data: StrategyProposalResult }>('/api/ai/learning/synthesize', {
        feedbackRecords: feedback.map((f) => ({
          rating: f.rating,
          feedbackType: f.feedbackType,
          comment: f.comment,
        })),
        salesOutcomes: outcomes.map((o) => ({
          outcomeType: o.outcomeType,
          strategyUsed: o.strategyUsed,
          blockingObjection: o.blockingObjection,
          product: o.product,
        })),
        knowledgeGaps: knowledgeGaps.map((g) => ({
          title: g.title,
          description: g.description,
        })),
        context: ctx,
      });

      const proposal = res.data;
      await createLearningRecord({
        workspaceId,
        recordType: 'strategy_proposal',
        title: proposal.title,
        description: `${proposal.description}\n\nCorrelation vs Causation Note: ${proposal.correlationVsCausationNote}`,
        evidenceSummary: proposal.evidenceSummary,
        proposedChange: proposal.proposedChange,
        instructionVersion: currentInstructionVersion + 1,
        createdBy: firebaseUser.uid,
        isAdmin,
        autoApprove: false,
      });

      notify('New Layer 5 strategy improvement proposed for review.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Strategy synthesis failed.', 'error');
    } finally {
      setSynthesizing(false);
    }
  };

  const handleReviewRecord = async (
    learningId: string,
    status: 'approved' | 'rejected' | 'rolled_back',
    reason: string,
  ) => {
    if (!firebaseUser) return;
    try {
      await reviewLearningRecord({
        learningId,
        status,
        reviewedBy: firebaseUser.uid,
        reason,
      });
      notify(`Learning record updated to ${status}.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Review update failed.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
            Adaptive Learning Centre
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            5-layer evolution via persistent memory, feedback constraints, outcome correlation,
            verified knowledge gaps, and approval-gated instruction versions (currently{' '}
            <span className="font-mono">v{currentInstructionVersion}</span>).
          </p>
        </div>
        <button
          type="button"
          disabled={synthesizing}
          onClick={() => void handleSynthesizeStrategy()}
          className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer self-start sm:self-auto"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{synthesizing ? 'Synthesizing...' : 'Propose Strategy Update'}</span>
        </button>
      </div>

      {/* Feedback Summary Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Total Feedback Records</div>
          <div className="text-2xl font-mono font-semibold tabular-nums mt-1">{feedback.length}</div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Helpful AI Responses</div>
          <div className="text-2xl font-mono font-semibold tabular-nums text-emerald-500 mt-1">
            {positiveFb.length}
          </div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Open Knowledge Gaps</div>
          <div className="text-2xl font-mono font-semibold tabular-nums text-amber-500 mt-1">
            {knowledgeGaps.filter((g) => g.status === 'pending_review').length}
          </div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Active Instruction Version</div>
          <div className="text-2xl font-mono font-semibold tabular-nums text-sky-500 mt-1">
            v{currentInstructionVersion}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Layer 1: Personal Memory Manager */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
            Layer 1 · Personal Conversational Memory ({memories.length})
          </h2>

          <form onSubmit={handleAddMemory} className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <select
                value={memType}
                onChange={(e) => setMemType(e.target.value as UserMemoryRecord['memoryType'])}
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              >
                <option value="winning_approach">Winning Approach</option>
                <option value="communication_style">Communication Style</option>
                <option value="common_objection">Common Objection</option>
                <option value="requested_script">Requested Script</option>
                <option value="training_weakness">Training Weakness</option>
                <option value="prospect_context">Prospect Context</option>
                <option value="preference">Executive Preference</option>
              </select>
              <select
                value={memConf}
                onChange={(e) => setMemConf(e.target.value as UserMemoryRecord['confidence'])}
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              >
                <option value="high">High confidence</option>
                <option value="medium">Medium confidence</option>
                <option value="low">Low confidence</option>
              </select>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={memContent}
                onChange={(e) => setMemContent(e.target.value)}
                placeholder="e.g. Keep WhatsApp first replies under 45 words..."
                className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-lg bg-sky-600 text-white text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </form>

          <div className="divide-y divide-slate-200 dark:divide-slate-800 max-h-80 overflow-y-auto">
            {memories.length === 0 ? (
              <p className="text-xs text-slate-500 py-4">
                No personal memory entries stored yet.
              </p>
            ) : (
              memories.map((m) => (
                <div key={m.memoryId} className="py-2.5 flex items-start justify-between gap-2 text-xs">
                  <div>
                    <div className="text-slate-500 capitalize">
                      {m.memoryType.replace('_', ' ')} · {m.confidence}
                    </div>
                    <div className="text-slate-800 dark:text-slate-200 mt-0.5">{m.memoryContent}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => void deleteUserMemory(m.memoryId)}
                    className="p-1 text-slate-400 hover:text-red-500 cursor-pointer shrink-0"
                    title="Delete memory"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Layer 2 Common Weaknesses */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Layer 2 · Recurring AI Weaknesses from Feedback
            </h3>
            {commonWeaknesses.length === 0 ? (
              <p className="text-xs text-slate-500">No negative feedback critiques logged yet.</p>
            ) : (
              <div className="space-y-1 text-xs">
                {commonWeaknesses.map(([label, count]) => (
                  <div key={label} className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span>{label}</span>
                    <span className="font-mono tabular-nums">{count}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Layers 4 & 5: Knowledge Gaps + Strategy Proposals & Version History */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Layer 5 · Strategy Improvements &amp; Instruction History
            </h2>
            {strategyRecords.length === 0 ? (
              <p className="text-xs text-slate-500">
                No strategy proposals yet. Click &ldquo;Propose Strategy Update&rdquo; once you
                have recorded feedback or sales outcomes.
              </p>
            ) : (
              <div className="space-y-3">
                {strategyRecords.map((rec) => (
                  <div
                    key={rec.learningId}
                    className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">
                          [v{rec.instructionVersion}] {rec.title}
                        </div>
                        <div className="text-slate-500 mt-0.5">
                          Status: <span className="font-medium capitalize">{rec.status.replace('_', ' ')}</span>
                          {rec.reason && ` · Reason: ${rec.reason}`}
                        </div>
                      </div>
                      {isAdmin && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          {rec.status === 'pending_review' && (
                            <>
                              <button
                                type="button"
                                onClick={() =>
                                  void handleReviewRecord(
                                    rec.learningId,
                                    'approved',
                                    'Approved based on executive feedback & outcome evidence',
                                  )
                                }
                                className="px-2 py-1 rounded bg-emerald-600 text-white inline-flex items-center gap-1 cursor-pointer"
                              >
                                <Check className="w-3 h-3" />
                                <span>Approve</span>
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  void handleReviewRecord(
                                    rec.learningId,
                                    'rejected',
                                    'Insufficient causal evidence',
                                  )
                                }
                                className="px-2 py-1 rounded bg-red-600 text-white inline-flex items-center gap-1 cursor-pointer"
                              >
                                <X className="w-3 h-3" />
                                <span>Reject</span>
                              </button>
                            </>
                          )}
                          {rec.status === 'approved' && (
                            <button
                              type="button"
                              onClick={() =>
                                void handleReviewRecord(
                                  rec.learningId,
                                  'rolled_back',
                                  'Rolled back by administrator',
                                )
                              }
                              className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 inline-flex items-center gap-1 cursor-pointer"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>Rollback</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                    <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {rec.description}
                    </p>
                    {rec.proposedChange && (
                      <div className="p-2 rounded bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200">
                        <span className="font-semibold">Instruction Rule: </span>
                        {rec.proposedChange}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Layer 4 · Knowledge Gaps Queue ({knowledgeGaps.length})
            </h2>
            {knowledgeGaps.length === 0 ? (
              <p className="text-xs text-slate-500">
                No open knowledge gaps flagged. Missing specs detected in Product or Objection
                Intelligence appear here.
              </p>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {knowledgeGaps.map((gap) => (
                  <div key={gap.learningId} className="py-3 flex items-start justify-between gap-3 text-xs">
                    <div>
                      <div className="font-medium text-slate-900 dark:text-white">{gap.title}</div>
                      <p className="text-slate-600 dark:text-slate-400 mt-0.5">{gap.description}</p>
                      <div className="text-slate-500 mt-1 capitalize">
                        Status: {gap.status.replace('_', ' ')}
                      </div>
                    </div>
                    {isAdmin && gap.status === 'pending_review' && (
                      <button
                        type="button"
                        onClick={() =>
                          void handleReviewRecord(
                            gap.learningId,
                            'approved',
                            'Resolved with verified Knowledge Base upload',
                          )
                        }
                        className="px-2.5 py-1 rounded bg-emerald-600 text-white whitespace-nowrap cursor-pointer"
                      >
                        Mark Resolved
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

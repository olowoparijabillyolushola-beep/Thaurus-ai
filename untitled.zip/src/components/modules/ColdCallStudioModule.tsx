import { ArrowRight, PhoneCall } from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import type { ColdCallPlaybookResult } from '../../types';

const TARGET_SEGMENTS = [
  'Experienced forex/index trader evaluating new prop firms',
  'Retail trader burned by strict drawdown rules elsewhere',
  'Active community trader looking for higher capital scaling',
  'Crypto/synthetic trader exploring funded accounts',
  'Returning lead who requested pricing earlier',
];

export function ColdCallStudioModule() {
  const { setActiveNav, setDraftSimScenario, buildAiContext, notify } = useSalesOs();
  const [targetSegment, setTargetSegment] = useState(TARGET_SEGMENTS[0]);
  const [challengeFocus, setChallengeFocus] = useState('Thaurus Guru Evaluation Challenges');
  const [callObjective, setCallObjective] = useState('Qualify trading style and secure commitment');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [playbook, setPlaybook] = useState<ColdCallPlaybookResult | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const ctx = buildAiContext(`${targetSegment} ${challengeFocus} ${notes}`);
      const res = await apiPostJson<{ data: ColdCallPlaybookResult }>('/api/ai/cold-call', {
        targetSegment,
        challengeFocus,
        callObjective,
        notes,
        context: ctx,
      });
      setPlaybook(res.data);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to generate cold call playbook.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleLaunchSimulation = () => {
    setDraftSimScenario({
      prospectType: 'Busy prospect',
      notes: `Cold call practice: ${targetSegment}. Objective: ${callObjective}.`,
    });
    setActiveNav('simulation');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
            Cold Call Studio
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Prepare two-way conversational call frameworks designed to invite prospect dialogue, not
            monologues.
          </p>
        </div>
        <button
          type="button"
          onClick={handleLaunchSimulation}
          className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer self-start sm:self-auto"
        >
          <span>Practise in Simulation</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <form
          onSubmit={handleGenerate}
          className="lg:col-span-4 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4 h-fit"
        >
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Target Prospect Segment
            </label>
            <select
              value={targetSegment}
              onChange={(e) => setTargetSegment(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            >
              {TARGET_SEGMENTS.map((seg) => (
                <option key={seg} value={seg}>
                  {seg}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Product / Challenge Focus
            </label>
            <input
              type="text"
              value={challengeFocus}
              onChange={(e) => setChallengeFocus(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Call Objective
            </label>
            <input
              type="text"
              value={callObjective}
              onChange={(e) => setCallObjective(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Prospect Background / Lead Source Notes
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Trader downloaded challenge guide yesterday from Lagos..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium cursor-pointer"
          >
            {loading ? 'Building Call Playbook...' : 'Generate Two-Way Playbook'}
          </button>
        </form>

        <div className="lg:col-span-8">
          {!playbook ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
              <PhoneCall className="w-8 h-8 text-sky-500 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Two-Way Cold Call Architect
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                Generates varied non-scripted openers, attention hooks, discovery prompts,
                conversational transitions, and live pushback pivots.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-5">
              <div>
                <h3 className="text-xs font-semibold text-sky-600 dark:text-sky-400 mb-2">
                  Opening Lines &amp; Natural Introduction
                </h3>
                <p className="text-sm text-slate-900 dark:text-white mb-2">
                  {playbook.naturalIntroduction}
                </p>
                <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                  {playbook.openingLines.map((line, i) => (
                    <li key={i}>{line}</li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Attention-Grabbing Questions
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {playbook.attentionQuestions.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Discovery Questions
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {playbook.discoveryQuestions.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Value-First Positioning
                  </h4>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {playbook.productPositioning}
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Conversational Transitions
                  </h4>
                  <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {playbook.conversationalTransitions.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Call Pushback Pivots
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {playbook.objectionPivots.map((op, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 text-xs"
                    >
                      <div className="font-medium text-slate-900 dark:text-white mb-1">
                        &ldquo;{op.objection}&rdquo;
                      </div>
                      <div className="text-slate-600 dark:text-slate-300">{op.pivot}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Closing Questions
                  </h4>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {playbook.closingQuestions.map((cq, i) => (
                      <li key={i}>{cq}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Follow-Up Strategy
                  </h4>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {playbook.followUpStrategy}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { AlertTriangle, Compass, ExternalLink, Search } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import { createLearningRecord } from '../../services/firestoreService';
import type { ProductQaResult } from '../../types';
import { retrieveRelevantKnowledgeChunks } from '../../utils/ragRetrieval';

export const PRODUCT_CATEGORIES = [
  'All',
  'Company information',
  'Challenge types',
  'Account sizes',
  'Pricing',
  'Profit targets',
  'Daily drawdown',
  'Maximum drawdown',
  'Evaluation requirements',
  'Minimum trading days',
  'Payout rules',
  'Profit splits',
  'Refund policies',
  'Trading restrictions',
  'Supported platforms',
  'Payment options',
  'Customer support',
  'Terms and conditions',
  'Approved testimonials',
  'Sales materials',
];

export function ProductIntelligenceModule() {
  const {
    firebaseUser,
    workspaceId,
    isAdmin,
    currentInstructionVersion,
    knowledgeSources,
    knowledgeChunks,
    setActiveNav,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [category, setCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [qaResult, setQaResult] = useState<ProductQaResult | null>(null);

  const matchedChunks = useMemo(() => {
    const res = retrieveRelevantKnowledgeChunks(
      searchQuery,
      knowledgeChunks,
      knowledgeSources,
      category,
      20,
    );
    return res.chunks;
  }, [searchQuery, knowledgeChunks, knowledgeSources, category]);

  const handleAskProductAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    setLoading(true);
    try {
      const ctx = buildAiContext(question, null, category);
      const res = await apiPostJson<{ data: ProductQaResult }>('/api/ai/product-qa', {
        question,
        categoryFilter: category,
        context: ctx,
      });
      setQaResult(res.data);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Product intelligence query failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleLogGap = async (gapTitle: string, gapDetail: string) => {
    if (!firebaseUser || !workspaceId) return;
    try {
      await createLearningRecord({
        workspaceId,
        recordType: 'knowledge_gap',
        title: gapTitle || `Missing product info: ${question.slice(0, 70)}`,
        description: gapDetail,
        evidenceSummary: `Question asked in Product Intelligence (${category}): "${question}"`,
        instructionVersion: currentInstructionVersion,
        createdBy: firebaseUser.uid,
        isAdmin,
      });
      notify('Knowledge gap logged for administrator verification.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to log knowledge gap.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
            Product Intelligence Centre
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Official primary source:{' '}
            <a
              href="https://thaurusguru.com/"
              target="_blank"
              rel="noreferrer"
              className="text-sky-600 dark:text-sky-400 hover:underline inline-flex items-center gap-1"
            >
              <span>thaurusguru.com</span>
              <ExternalLink className="w-3 h-3" />
            </a>{' '}
            · Answers strictly cite approved imported documents and flag gaps.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setActiveNav('knowledge')}
          className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap cursor-pointer self-start sm:self-auto"
        >
          Import / Upload Sources
        </button>
      </div>

      {/* RAG Product Q&A */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
        <form onSubmit={handleAskProductAi} className="flex flex-col sm:flex-row gap-2">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="sm:w-56 px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
          >
            {PRODUCT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a factual question (e.g. What is the daily drawdown on 2-step evaluations?)"
            className="flex-1 px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm"
          />
          <button
            type="submit"
            disabled={loading || !question.trim()}
            className="px-5 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium whitespace-nowrap cursor-pointer"
          >
            {loading ? 'Verifying...' : 'Ask Verified AI'}
          </button>
        </form>

        {qaResult && (
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <p className="text-sm text-slate-900 dark:text-slate-100 leading-relaxed whitespace-pre-wrap">
              {qaResult.answer}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <div className="font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Supporting Source Citations
                </div>
                {qaResult.sourceCitations.length === 0 ? (
                  <p className="text-slate-500">No approved source chunks cited.</p>
                ) : (
                  <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                    {qaResult.sourceCitations.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                )}
              </div>

              <div>
                <div className="font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Verified Claims
                </div>
                {qaResult.verifiedClaims.length === 0 ? (
                  <p className="text-slate-500">None verified from current documents.</p>
                ) : (
                  <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                    {qaResult.verifiedClaims.map((vc, i) => (
                      <li key={i}>{vc}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {qaResult.detectedConflicts.length > 0 && (
              <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-800 dark:text-amber-200">
                <div className="font-semibold mb-1">Source Conflicts Detected</div>
                <ul className="list-disc pl-4 space-y-0.5">
                  {qaResult.detectedConflicts.map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>
            )}

            {qaResult.missingInfoGaps.length > 0 && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 flex items-start justify-between gap-3 text-xs text-red-800 dark:text-red-200">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                  <div>
                    <div className="font-semibold mb-1">Missing Information Gaps</div>
                    <ul className="list-disc pl-4 space-y-0.5">
                      {qaResult.missingInfoGaps.map((g, i) => (
                        <li key={i}>{g}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    void handleLogGap(
                      qaResult.suggestedKnowledgeGapTitle,
                      qaResult.missingInfoGaps.join('; '),
                    )
                  }
                  className="px-3 py-1.5 rounded bg-red-600 text-white font-medium whitespace-nowrap cursor-pointer"
                >
                  Create Gap Record
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Searchable Verified Knowledge Explorer */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-sky-500" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Verified Knowledge Explorer ({matchedChunks.length} matching chunks)
            </h2>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter chunks by keyword..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>
        </div>

        {matchedChunks.length === 0 ? (
          <div className="py-10 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              No approved knowledge chunks found for this filter.
            </p>
            <button
              type="button"
              onClick={() => setActiveNav('knowledge')}
              className="mt-3 px-4 py-2 rounded-lg bg-sky-600 text-white text-xs font-medium cursor-pointer"
            >
              Go to Knowledge Base to Import Documents
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {matchedChunks.map((chunk, i) => (
              <div key={i} className="py-3.5 space-y-1.5">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-medium text-sky-600 dark:text-sky-400">
                    {chunk.sourceTitle}
                  </span>
                  <span>·</span>
                  <span className="font-mono">v{chunk.documentVersion}</span>
                  <span>·</span>
                  <span>{chunk.category}</span>
                  <span>·</span>
                  <span>{chunk.sectionTitle}</span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {chunk.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

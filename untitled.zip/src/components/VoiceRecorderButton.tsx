import { Loader2, Mic, Square } from 'lucide-react';
import React from 'react';
import { useVoiceRecorder } from '../hooks/useVoiceRecorder';

interface VoiceRecorderButtonProps {
  contextHint?: string;
  disabled?: boolean;
  label?: string;
  onTranscript: (text: string) => void;
  onError: (msg: string) => void;
}

function formatTimer(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const VoiceRecorderButton: React.FC<VoiceRecorderButtonProps> = ({
  contextHint,
  disabled = false,
  label,
  onTranscript,
  onError,
}) => {
  const { isRecording, isTranscribing, elapsedSec, toggleRecording } = useVoiceRecorder({
    contextHint,
    onTranscript,
    onError,
  });

  return (
    <button
      type="button"
      disabled={disabled || isTranscribing}
      onClick={toggleRecording}
      aria-label={isRecording ? 'Stop voice recording' : 'Start voice recording'}
      title={
        isTranscribing
          ? 'Transcribing audio with Gemini...'
          : isRecording
            ? 'Stop recording and transcribe'
            : 'Speak live summary or reply'
      }
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-2.5 py-2.5 text-xs font-medium transition-colors cursor-pointer shrink-0 whitespace-nowrap disabled:opacity-50 ${
        isRecording
          ? 'border-red-500 bg-red-600 text-white hover:bg-red-500'
          : isTranscribing
            ? 'border-sky-500/40 bg-sky-500/10 text-sky-600 dark:text-sky-400'
            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
      }`}
    >
      {isTranscribing ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin shrink-0" />
          <span>Transcribing...</span>
        </>
      ) : isRecording ? (
        <>
          <Square className="w-3.5 h-3.5 fill-current shrink-0" />
          <span className="font-mono tabular-nums">{formatTimer(elapsedSec)}</span>
        </>
      ) : (
        <>
          <Mic className="w-4 h-4 shrink-0" />
          {label && <span>{label}</span>}
        </>
      )}
    </button>
  );
};

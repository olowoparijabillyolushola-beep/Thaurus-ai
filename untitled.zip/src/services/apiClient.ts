import { auth } from '../firebase';

async function getAuthHeaders(): Promise<Record<string, string>> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('You must be signed in to run AI intelligence requests.');
  }
  const token = await user.getIdToken();
  return {
    Authorization: `Bearer ${token}`,
  };
}

export async function apiPostJson<TResponse>(
  endpoint: string,
  payload: Record<string, unknown>,
): Promise<TResponse> {
  const authHeaders = await getAuthHeaders();
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders,
    },
    body: JSON.stringify(payload),
  });

  const body = (await response.json().catch(() => ({}))) as { error?: string } & TResponse;
  if (!response.ok) {
    throw new Error(body.error || `Request failed with status ${response.status}`);
  }
  return body;
}

export async function apiUploadFile<TResponse>(
  endpoint: string,
  formData: FormData,
): Promise<TResponse> {
  const authHeaders = await getAuthHeaders();
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      ...authHeaders,
    },
    body: formData,
  });

  const body = (await response.json().catch(() => ({}))) as { error?: string } & TResponse;
  if (!response.ok) {
    throw new Error(body.error || `Upload failed with status ${response.status}`);
  }
  return body;
}

export async function apiStreamLiveAssist(
  payload: Record<string, unknown>,
  onChunk: (chunkText: string) => void,
): Promise<{ resolvedMode: 'fast' | 'deep'; tokenUsage: number; latencyMs: number }> {
  const authHeaders = await getAuthHeaders();
  const response = await fetch('/api/ai/live-assist/stream', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok || !response.body) {
    const errBody = (await response.json().catch(() => ({}))) as { error?: string };
    throw new Error(errBody.error || `Streaming request failed (${response.status})`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let finalMeta = { resolvedMode: 'fast' as 'fast' | 'deep', tokenUsage: 0, latencyMs: 0 };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop() ?? '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const jsonStr = trimmed.slice(5).trim();
      if (!jsonStr) continue;
      const evt = JSON.parse(jsonStr) as {
        type: 'chunk' | 'done' | 'error';
        text?: string;
        error?: string;
        resolvedMode?: 'fast' | 'deep';
        tokenUsage?: number;
        latencyMs?: number;
      };
      if (evt.type === 'error') {
        throw new Error(evt.error || 'AI stream error');
      }
      if (evt.type === 'chunk' && evt.text) {
        onChunk(evt.text);
      }
      if (evt.type === 'done') {
        finalMeta = {
          resolvedMode: evt.resolvedMode ?? 'fast',
          tokenUsage: evt.tokenUsage ?? 0,
          latencyMs: evt.latencyMs ?? 0,
        };
      }
    }
  }

  return finalMeta;
}

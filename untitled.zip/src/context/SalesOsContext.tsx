import type { User } from 'firebase/auth';
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { auth, googleProvider } from '../firebase';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import {
  bootstrapUserAndWorkspace,
  subscribeUserCollections,
  updateUserProfile,
} from '../services/firestoreService';
import type {
  AllowedModel,
  CommunicationStyle,
  ConversationRecord,
  FeedbackRecord,
  KnowledgeChunkRecord,
  KnowledgeSourceRecord,
  LearningRecord,
  NavSection,
  ProspectRecord,
  SalesOutcomeRecord,
  SimulationRecord,
  ThinkingMode,
  UserMemoryRecord,
  UserProfile,
  WorkspaceRecord,
} from '../types';
import {
  loadLastActiveUid,
  loadOfflineFieldCache,
  saveOfflineFieldCache,
} from '../utils/offlineFieldCache';
import { buildIntelligenceContext } from '../utils/ragRetrieval';

interface ToastMessage {
  id: string;
  tone: 'info' | 'success' | 'error';
  text: string;
}

interface SalesOsContextValue {
  authLoading: boolean;
  isOnline: boolean;
  offlineLastSyncedAt: string | null;
  refreshOfflineCache: () => void;
  firebaseUser: User | null;
  profile: UserProfile | null;
  workspaceId: string;
  isAdmin: boolean;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  activeNav: NavSection;
  setActiveNav: (nav: NavSection) => void;
  thinkingMode: ThinkingMode;
  setThinkingMode: (mode: ThinkingMode) => void;
  selectedModel: AllowedModel;
  setSelectedModel: (model: AllowedModel) => void;
  communicationStyle: CommunicationStyle;
  setCommunicationStyle: (style: CommunicationStyle) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  draftProspectId: string | null;
  setDraftProspectId: (id: string | null) => void;
  openProspectInLiveAssistant: (prospectId: string) => void;
  draftAnalysisText: string;
  setDraftAnalysisText: (text: string) => void;
  draftSimScenario: { prospectType: string; notes: string } | null;
  setDraftSimScenario: (s: { prospectType: string; notes: string } | null) => void;
  conversations: ConversationRecord[];
  prospects: ProspectRecord[];
  memories: UserMemoryRecord[];
  feedback: FeedbackRecord[];
  outcomes: SalesOutcomeRecord[];
  simulations: SimulationRecord[];
  knowledgeSources: KnowledgeSourceRecord[];
  knowledgeChunks: KnowledgeChunkRecord[];
  learningRecords: LearningRecord[];
  workspaces: WorkspaceRecord[];
  currentInstructionVersion: number;
  buildAiContext: (
    query: string,
    prospect?: ProspectRecord | null,
    categoryFilter?: string,
  ) => ReturnType<typeof buildIntelligenceContext>;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  notify: (text: string, tone?: ToastMessage['tone']) => void;
  authError: string | null;
}

const SalesOsContext = createContext<SalesOsContextValue | null>(null);

export function SalesOsProvider({ children }: { children: React.ReactNode }) {
  const isOnline = useOnlineStatus();
  const [authLoading, setAuthLoading] = useState(true);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [workspaceId, setWorkspaceId] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [offlineLastSyncedAt, setOfflineLastSyncedAt] = useState<string | null>(null);

  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [activeNav, setActiveNav] = useState<NavSection>('overview');
  const [thinkingMode, setThinkingModeState] = useState<ThinkingMode>('auto');
  const [selectedModel, setSelectedModelState] = useState<AllowedModel>('gemini-4-hydrogen');
  const [communicationStyle, setCommunicationStyleState] =
    useState<CommunicationStyle>('Natural');

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [draftProspectId, setDraftProspectId] = useState<string | null>(null);
  const [draftAnalysisText, setDraftAnalysisText] = useState('');
  const [draftSimScenario, setDraftSimScenario] = useState<{
    prospectType: string;
    notes: string;
  } | null>(null);

  const [conversations, setConversations] = useState<ConversationRecord[]>([]);
  const [prospects, setProspects] = useState<ProspectRecord[]>([]);
  const [memories, setMemories] = useState<UserMemoryRecord[]>([]);
  const [feedback, setFeedback] = useState<FeedbackRecord[]>([]);
  const [outcomes, setOutcomes] = useState<SalesOutcomeRecord[]>([]);
  const [simulations, setSimulations] = useState<SimulationRecord[]>([]);
  const [knowledgeSources, setKnowledgeSources] = useState<KnowledgeSourceRecord[]>([]);
  const [knowledgeChunks, setKnowledgeChunks] = useState<KnowledgeChunkRecord[]>([]);
  const [learningRecords, setLearningRecords] = useState<LearningRecord[]>([]);
  const [workspaces, setWorkspaces] = useState<WorkspaceRecord[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const notify = useCallback((text: string, tone: ToastMessage['tone'] = 'info') => {
    const id = crypto.randomUUID().slice(0, 8);
    setToasts((prev) => [...prev.slice(-3), { id, tone, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const openProspectInLiveAssistant = useCallback((prospectId: string) => {
    setActiveConversationId(null);
    setDraftProspectId(prospectId);
    setActiveNav('live_assistant');
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    let unsubData: (() => void) | null = null;
    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubData) {
        unsubData();
        unsubData = null;
      }

      if (!user) {
        // When offline in standalone PWA, hydrate cached field data if a previous verified session exists
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          const lastUid = loadLastActiveUid();
          const cached = lastUid ? loadOfflineFieldCache(lastUid) : null;
          if (cached) {
            setProfile(cached.profile);
            setWorkspaceId(cached.workspaceId);
            setProspects(cached.prospects);
            setKnowledgeSources(cached.knowledgeSources);
            setKnowledgeChunks(cached.knowledgeChunks);
            setOfflineLastSyncedAt(cached.lastSyncedAt);
            setAuthLoading(false);
            return;
          }
        }

        setFirebaseUser(null);
        setProfile(null);
        setWorkspaceId('');
        setConversations([]);
        setProspects([]);
        setMemories([]);
        setFeedback([]);
        setOutcomes([]);
        setSimulations([]);
        setKnowledgeSources([]);
        setKnowledgeChunks([]);
        setLearningRecords([]);
        setWorkspaces([]);
        setOfflineLastSyncedAt(null);
        setAuthLoading(false);
        return;
      }

      setFirebaseUser(user);
      setAuthError(null);

      // Hydrate immediately from local field cache so offline Knowledge Base & Prospects appear with zero delay
      const cached = loadOfflineFieldCache(user.uid);
      if (cached) {
        if (cached.profile) setProfile(cached.profile);
        if (cached.workspaceId) setWorkspaceId(cached.workspaceId);
        if (cached.prospects.length > 0) setProspects(cached.prospects);
        if (cached.knowledgeSources.length > 0) setKnowledgeSources(cached.knowledgeSources);
        if (cached.knowledgeChunks.length > 0) setKnowledgeChunks(cached.knowledgeChunks);
        setOfflineLastSyncedAt(cached.lastSyncedAt);
      }

      try {
        const { profile: userProfile, workspaceId: wsId } = await bootstrapUserAndWorkspace(user);
        setProfile(userProfile);
        setWorkspaceId(wsId);
        setThinkingModeState(userProfile.defaultThinkingMode || 'auto');
        setCommunicationStyleState(userProfile.communicationStyle || 'Natural');
        const prefTheme = userProfile.preferences?.theme;
        if (prefTheme === 'light' || prefTheme === 'dark') {
          setTheme(prefTheme);
        }
        const prefModel = userProfile.preferences?.preferredModel;
        if (prefModel === 'gemini-3.1-flash-lite' || prefModel === 'gemini-4-hydrogen') {
          setSelectedModelState(prefModel);
        }

        unsubData = subscribeUserCollections(user.uid, {
          onConversations: setConversations,
          onProspects: setProspects,
          onMemories: setMemories,
          onFeedback: setFeedback,
          onOutcomes: setOutcomes,
          onSimulations: setSimulations,
          onKnowledgeSources: setKnowledgeSources,
          onKnowledgeChunks: setKnowledgeChunks,
          onLearningRecords: setLearningRecords,
          onWorkspaces: setWorkspaces,
        });
      } catch (err) {
        // If offline and we already hydrated from field cache, stay usable in Offline Field Mode
        if (typeof navigator !== 'undefined' && !navigator.onLine && cached) {
          setAuthLoading(false);
          return;
        }
        const msg = err instanceof Error ? err.message : 'Failed to initialize workspace.';
        setAuthError(msg);
      } finally {
        setAuthLoading(false);
      }
    });

    return () => {
      unsubAuth();
      if (unsubData) unsubData();
    };
  }, []);

  const refreshOfflineCache = useCallback(() => {
    const uid = firebaseUser?.uid || profile?.uid;
    if (!uid || !workspaceId) return;
    const syncedAt = new Date().toISOString();
    saveOfflineFieldCache({
      uid,
      workspaceId,
      profile,
      prospects,
      knowledgeSources,
      knowledgeChunks,
      lastSyncedAt: syncedAt,
    });
    setOfflineLastSyncedAt(syncedAt);
  }, [firebaseUser?.uid, profile, workspaceId, prospects, knowledgeSources, knowledgeChunks]);

  // Keep offline field cache automatically synchronized whenever live data updates
  useEffect(() => {
    const uid = firebaseUser?.uid;
    if (!uid || !workspaceId) return;
    const syncedAt = new Date().toISOString();
    saveOfflineFieldCache({
      uid,
      workspaceId,
      profile,
      prospects,
      knowledgeSources,
      knowledgeChunks,
      lastSyncedAt: syncedAt,
    });
    setOfflineLastSyncedAt(syncedAt);
  }, [firebaseUser?.uid, workspaceId, profile, prospects, knowledgeSources, knowledgeChunks]);

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in cancelled or failed.';
      setAuthError(msg);
    }
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      if (profile) {
        void updateUserProfile(profile.uid, {
          preferences: { ...(profile.preferences ?? {}), theme: next },
        }).catch(() => {});
      }
      return next;
    });
  }, [profile]);

  const setThinkingMode = useCallback(
    (mode: ThinkingMode) => {
      setThinkingModeState(mode);
      if (profile) {
        void updateUserProfile(profile.uid, { defaultThinkingMode: mode }).catch(() => {});
      }
    },
    [profile],
  );

  const setSelectedModel = useCallback(
    (model: AllowedModel) => {
      setSelectedModelState(model);
      if (profile) {
        void updateUserProfile(profile.uid, {
          preferences: { ...(profile.preferences ?? {}), preferredModel: model },
        }).catch(() => {});
      }
    },
    [profile],
  );

  const setCommunicationStyle = useCallback(
    (style: CommunicationStyle) => {
      setCommunicationStyleState(style);
      if (profile) {
        void updateUserProfile(profile.uid, { communicationStyle: style }).catch(() => {});
      }
    },
    [profile],
  );

  const isAdmin = useMemo(() => {
    if (!profile) return false;
    return (
      profile.role === 'owner' ||
      profile.role === 'administrator' ||
      profile.email === 'echelontix@gmail.com'
    );
  }, [profile]);

  const currentInstructionVersion = useMemo(() => {
    const approved = learningRecords.filter(
      (r) => r.status === 'approved' && r.recordType !== 'knowledge_gap',
    );
    if (approved.length === 0) return 1;
    return Math.max(1, ...approved.map((r) => r.instructionVersion));
  }, [learningRecords]);

  const buildAiContext = useCallback(
    (query: string, prospect?: ProspectRecord | null, categoryFilter = 'All') => {
      return buildIntelligenceContext({
        query,
        model: selectedModel,
        thinkingMode,
        communicationStyle,
        chunks: knowledgeChunks,
        sources: knowledgeSources,
        memories,
        feedback,
        learningRecords,
        prospect,
        categoryFilter,
      });
    },
    [
      selectedModel,
      thinkingMode,
      communicationStyle,
      knowledgeChunks,
      knowledgeSources,
      memories,
      feedback,
      learningRecords,
    ],
  );

  return (
    <SalesOsContext.Provider
      value={{
        authLoading,
        isOnline,
        offlineLastSyncedAt,
        refreshOfflineCache,
        firebaseUser,
        profile,
        workspaceId,
        isAdmin,
        theme,
        toggleTheme,
        activeNav,
        setActiveNav,
        thinkingMode,
        setThinkingMode,
        selectedModel,
        setSelectedModel,
        communicationStyle,
        setCommunicationStyle,
        activeConversationId,
        setActiveConversationId,
        draftProspectId,
        setDraftProspectId,
        openProspectInLiveAssistant,
        draftAnalysisText,
        setDraftAnalysisText,
        draftSimScenario,
        setDraftSimScenario,
        conversations,
        prospects,
        memories,
        feedback,
        outcomes,
        simulations,
        knowledgeSources,
        knowledgeChunks,
        learningRecords,
        workspaces,
        currentInstructionVersion,
        buildAiContext,
        signInWithGoogle,
        logout,
        notify,
        authError,
      }}
    >
      {children}
      {toasts.length > 0 && (
        <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`px-4 py-2.5 rounded-lg border text-sm shadow-lg transition-all ${
                t.tone === 'error'
                  ? 'bg-red-950/95 border-red-700/60 text-red-100'
                  : t.tone === 'success'
                    ? 'bg-emerald-950/95 border-emerald-700/60 text-emerald-100'
                    : 'bg-slate-900/95 border-slate-700 text-slate-100'
              }`}
            >
              {t.text}
            </div>
          ))}
        </div>
      )}
    </SalesOsContext.Provider>
  );
}

export function useSalesOs() {
  const ctx = useContext(SalesOsContext);
  if (!ctx) throw new Error('useSalesOs must be used inside SalesOsProvider');
  return ctx;
}
